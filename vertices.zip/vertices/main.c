/**
 * \file wireframe.c
 *
 * \brief Implementação do arquivo principal de renderização do modelo 3D.
 *
 * \author
 * Petrucio Ricardo Tavares de Medeiros \n
 * Universidade Federal Rural do Semi-Árido \n
 * Departamento de Engenharias e Tecnologia \n
 * petrucio at ufersa (dot) edu (dot) br
 *
 * \version 1.0
 * \date May 2025
 */

#include "model.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  Vertex vertices[MAX_VERTICES];
  Face faces[MAX_FACES];
  int vcount, fcount;

  if (argc < 4) {
    printf("Ta faltando coisa aí\n");
    printf("Usage: <executavel> <nome do modelo> <nome da saida> <tipo de "
           "saida (a: aramado | c: nuvem de pontos)>\n");
  }

  char *obj = argv[1];
  char *saida = argv[2];
  char *tipo = argv[3];

  if (*tipo != 'a' && *tipo != 'c') {
    printf("Tipos de saída: \n");
    printf("\ta -Aramado\n");
    printf("\tc - Nuvem de pontos \n");

    printf("Usage: <executavel> <nome do modelo> <nome da saida> <tipo de "
           "saida (a: aramado | c: nuvem de pontos)>\n");
    return 1;
  }

  clr();

  // Lê o arquivo OBJ enviado
  if (!load_obj(obj, vertices, &vcount, faces, &fcount)) {
    return 1;
  }

  // Renderiza as faces no framebuffer
  if (*tipo == 'c') {
    clr_C();
    render_faces_c(vertices, faces, vcount, fcount);
  } else {
    render_faces(vertices, faces, vcount, fcount);
  }

  save(saida);

  return 0;
}
