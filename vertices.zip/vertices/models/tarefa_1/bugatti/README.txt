Hi, thanks for downloadiing this model.It was created by Bob Kimani (Kimz Auto).
if you like the model please feel free to donate to my PayPal account at
 bobiankimani@gmail.com
Or simply buy the model for a price of your choice here

https://sellfy.com/p/FrEB/
I would reaaly appreciate it even if its just one dollar.Thanks;)
Please include this credit when you use the file.
Regards Bob :)